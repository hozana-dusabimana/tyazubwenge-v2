<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/User.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        // Login and get API token
        $data = json_decode(file_get_contents('php://input'), true);
        $username = $data['username'] ?? $_POST['username'] ?? '';
        $password = $data['password'] ?? $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Username and password are required']);
            exit;
        }
        
        $user = new User();
        $result = $user->login($username, $password);
        
        if ($result['success']) {
            // Generate API token (simple token for now, can be enhanced with JWT)
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
            
            // Store token in session or database (for now using session)
            $_SESSION['api_token'] = $token;
            $_SESSION['api_token_expires'] = $expires;
            
            echo json_encode([
                'success' => true,
                'token' => $token,
                'expires' => $expires,
                'user' => [
                    'id' => $_SESSION['user_id'],
                    'username' => $_SESSION['username'],
                    'role' => $_SESSION['role'],
                    'branch_id' => $_SESSION['branch_id'] ?? null
                ]
            ]);
        } else {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => $result['message']]);
        }
        break;
        
    case 'GET':
        // Verify token
        $token = $_GET['token'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        $token = str_replace('Bearer ', '', $token);
        
        if (empty($token)) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Token required']);
            exit;
        }
        
        // Check if token is valid (in session for now)
        if (isset($_SESSION['api_token']) && $_SESSION['api_token'] === $token) {
            if (isset($_SESSION['api_token_expires']) && $_SESSION['api_token_expires'] > date('Y-m-d H:i:s')) {
                echo json_encode([
                    'success' => true,
                    'valid' => true,
                    'user' => [
                        'id' => $_SESSION['user_id'],
                        'username' => $_SESSION['username'],
                        'role' => $_SESSION['role'],
                        'branch_id' => $_SESSION['branch_id'] ?? null
                    ]
                ]);
            } else {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token expired']);
            }
        } else {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Invalid token']);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>

