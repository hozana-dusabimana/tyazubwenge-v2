<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../classes/Product.php';
require_once __DIR__ . '/../classes/Stock.php';
require_once __DIR__ . '/../classes/Customer.php';
require_once __DIR__ . '/../classes/Sale.php';

// Verify API token
$token = $_GET['token'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token = str_replace('Bearer ', '', $token);

if (empty($token) || !isset($_SESSION['api_token']) || $_SESSION['api_token'] !== $token) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Invalid or missing token.']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$entity = $_GET['entity'] ?? 'all';
$lastSync = $_GET['last_sync'] ?? null;
$branchId = $_SESSION['branch_id'] ?? null;

$database = new Database();
$conn = $database->getConnection();

$response = [
    'success' => true,
    'server_time' => date('Y-m-d H:i:s'),
    'data' => []
];

try {
    // Download products
    if ($entity === 'all' || $entity === 'products') {
        $product = new Product();
        $query = "SELECT * FROM products";
        $params = [];
        
        if ($lastSync) {
            $query .= " WHERE updated_at > :last_sync OR created_at > :last_sync";
            $params[':last_sync'] = $lastSync;
        }
        
        $query .= " ORDER BY id ASC";
        $stmt = $conn->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $response['data']['products'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Download stock
    if ($entity === 'all' || $entity === 'stock') {
        $query = "SELECT si.*, p.name as product_name, p.sku, p.unit as product_unit 
                  FROM stock_inventory si 
                  JOIN products p ON si.product_id = p.id 
                  WHERE si.branch_id = :branch_id";
        $params = [':branch_id' => $branchId];
        
        if ($lastSync) {
            $query .= " AND (si.updated_at > :last_sync OR si.created_at > :last_sync)";
            $params[':last_sync'] = $lastSync;
        }
        
        $query .= " ORDER BY si.id ASC";
        $stmt = $conn->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $response['data']['stock'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Download customers
    if ($entity === 'all' || $entity === 'customers') {
        $query = "SELECT * FROM customers";
        $params = [];
        
        if ($lastSync) {
            $query .= " WHERE updated_at > :last_sync OR created_at > :last_sync";
            $params[':last_sync'] = $lastSync;
        }
        
        $query .= " ORDER BY id ASC";
        $stmt = $conn->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $response['data']['customers'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Download sales
    if ($entity === 'all' || $entity === 'sales') {
        $query = "SELECT s.*, 
                  GROUP_CONCAT(CONCAT(si.product_id, ':', si.quantity, ':', si.unit_price, ':', si.total) SEPARATOR '|') as items
                  FROM sales s
                  LEFT JOIN sale_items si ON s.id = si.sale_id
                  WHERE s.branch_id = :branch_id";
        $params = [':branch_id' => $branchId];
        
        if ($lastSync) {
            $query .= " AND (s.updated_at > :last_sync OR s.created_at > :last_sync)";
            $params[':last_sync'] = $lastSync;
        }
        
        $query .= " GROUP BY s.id ORDER BY s.id ASC";
        $stmt = $conn->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get sale items separately
        foreach ($sales as &$sale) {
            $itemsQuery = "SELECT * FROM sale_items WHERE sale_id = :sale_id";
            $itemsStmt = $conn->prepare($itemsQuery);
            $itemsStmt->bindParam(':sale_id', $sale['id']);
            $itemsStmt->execute();
            $sale['items'] = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        $response['data']['sales'] = $sales;
    }
    
    // Download categories
    if ($entity === 'all' || $entity === 'categories') {
        $query = "SELECT * FROM categories";
        if ($lastSync) {
            $query .= " WHERE updated_at > :last_sync OR created_at > :last_sync";
        }
        $stmt = $conn->prepare($query);
        if ($lastSync) {
            $stmt->bindParam(':last_sync', $lastSync);
        }
        $stmt->execute();
        $response['data']['categories'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Download brands
    if ($entity === 'all' || $entity === 'brands') {
        $query = "SELECT * FROM brands";
        if ($lastSync) {
            $query .= " WHERE updated_at > :last_sync OR created_at > :last_sync";
        }
        $stmt = $conn->prepare($query);
        if ($lastSync) {
            $stmt->bindParam(':last_sync', $lastSync);
        }
        $stmt->execute();
        $response['data']['brands'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Download suppliers
    if ($entity === 'all' || $entity === 'suppliers') {
        $query = "SELECT * FROM suppliers";
        if ($lastSync) {
            $query .= " WHERE updated_at > :last_sync OR created_at > :last_sync";
        }
        $stmt = $conn->prepare($query);
        if ($lastSync) {
            $stmt->bindParam(':last_sync', $lastSync);
        }
        $stmt->execute();
        $response['data']['suppliers'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    echo json_encode($response);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Download failed: ' . $e->getMessage()
    ]);
}
?>

