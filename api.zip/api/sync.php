<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../classes/Sale.php';
require_once __DIR__ . '/../classes/Stock.php';
require_once __DIR__ . '/../classes/Product.php';
require_once __DIR__ . '/../classes/Customer.php';

// Verify API token
$token = $_GET['token'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? $_POST['token'] ?? '';
$token = str_replace('Bearer ', '', $token);

if (empty($token) || !isset($_SESSION['api_token']) || $_SESSION['api_token'] !== $token) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Invalid or missing token.']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$database = new Database();
$conn = $database->getConnection();
$branchId = $_SESSION['branch_id'] ?? null;

switch ($method) {
    case 'GET':
        // Get sync status and last sync timestamp
        $lastSync = $_GET['last_sync'] ?? null;
        $entity = $_GET['entity'] ?? 'all';
        
        $response = [
            'success' => true,
            'server_time' => date('Y-m-d H:i:s'),
            'last_sync' => $lastSync,
            'data' => []
        ];
        
        if ($entity === 'all' || $entity === 'sales') {
            $sale = new Sale();
            $query = "SELECT COUNT(*) as count, MAX(updated_at) as last_update FROM sales WHERE branch_id = :branch_id";
            if ($lastSync) {
                $query .= " AND updated_at > :last_sync";
            }
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':branch_id', $branchId);
            if ($lastSync) {
                $stmt->bindParam(':last_sync', $lastSync);
            }
            $stmt->execute();
            $salesData = $stmt->fetch(PDO::FETCH_ASSOC);
            $response['data']['sales'] = $salesData;
        }
        
        if ($entity === 'all' || $entity === 'stock') {
            $query = "SELECT COUNT(*) as count, MAX(updated_at) as last_update FROM stock_inventory WHERE branch_id = :branch_id";
            if ($lastSync) {
                $query .= " AND updated_at > :last_sync";
            }
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':branch_id', $branchId);
            if ($lastSync) {
                $stmt->bindParam(':last_sync', $lastSync);
            }
            $stmt->execute();
            $stockData = $stmt->fetch(PDO::FETCH_ASSOC);
            $response['data']['stock'] = $stockData;
        }
        
        if ($entity === 'all' || $entity === 'products') {
            $query = "SELECT COUNT(*) as count, MAX(updated_at) as last_update FROM products";
            if ($lastSync) {
                $query .= " WHERE updated_at > :last_sync";
            }
            $stmt = $conn->prepare($query);
            if ($lastSync) {
                $stmt->bindParam(':last_sync', $lastSync);
            }
            $stmt->execute();
            $productsData = $stmt->fetch(PDO::FETCH_ASSOC);
            $response['data']['products'] = $productsData;
        }
        
        echo json_encode($response);
        break;
        
    case 'POST':
        // Bulk sync data from desktop app
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['entity']) || !isset($data['records'])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Entity and records are required']);
            exit;
        }
        
        $entity = $data['entity'];
        $records = $data['records'];
        $results = [
            'success' => true,
            'synced' => 0,
            'failed' => 0,
            'errors' => []
        ];
        
        try {
            $conn->beginTransaction();
            
            foreach ($records as $record) {
                try {
                    switch ($entity) {
                        case 'sales':
                            $sale = new Sale();
                            // Check if sale exists (by local_id or invoice_number)
                            $localId = $record['local_id'] ?? null;
                            $invoiceNumber = $record['invoice_number'] ?? null;
                            
                            if ($localId) {
                                // Check if already synced
                                $checkQuery = "SELECT id FROM sales WHERE local_id = :local_id";
                                $checkStmt = $conn->prepare($checkQuery);
                                $checkStmt->bindParam(':local_id', $localId);
                                $checkStmt->execute();
                                if ($checkStmt->fetch()) {
                                    continue; // Already synced
                                }
                            }
                            
                            // Handle invoice_number if provided (for offline sales)
                            if (isset($record['invoice_number'])) {
                                // Check if invoice already exists
                                $checkInvoiceQuery = "SELECT id FROM sales WHERE invoice_number = :invoice_number";
                                $checkInvoiceStmt = $conn->prepare($checkInvoiceQuery);
                                $checkInvoiceStmt->bindParam(':invoice_number', $record['invoice_number']);
                                $checkInvoiceStmt->execute();
                                if ($checkInvoiceStmt->fetch()) {
                                    continue; // Already exists
                                }
                            }
                            
                            $record['user_id'] = $_SESSION['user_id'];
                            $record['branch_id'] = $branchId;
                            $record['created_at'] = $record['created_at'] ?? date('Y-m-d H:i:s');
                            
                            // Map field names if needed
                            if (isset($record['subtotal'])) {
                                $record['total_amount'] = $record['subtotal'];
                            }
                            if (!isset($record['payment_status'])) {
                                $record['payment_status'] = 'completed';
                            }
                            if (!isset($record['sale_type'])) {
                                $record['sale_type'] = 'retail';
                            }
                            
                            $result = $sale->create($record);
                            
                            if ($result && isset($result['success']) && $result['success'] && isset($result['sale_id'])) {
                                $saleId = $result['sale_id'];
                                
                                // Store local_id in sales table and mapping
                                if ($localId) {
                                    $updateLocalQuery = "UPDATE sales SET local_id = :local_id WHERE id = :id";
                                    $updateLocalStmt = $conn->prepare($updateLocalQuery);
                                    $updateLocalStmt->bindParam(':local_id', $localId);
                                    $updateLocalStmt->bindParam(':id', $saleId);
                                    $updateLocalStmt->execute();
                                    
                                    $mapQuery = "INSERT INTO sync_mappings (entity_type, local_id, server_id, created_at) 
                                                VALUES ('sales', :local_id, :server_id, NOW())
                                                ON DUPLICATE KEY UPDATE server_id = :server_id";
                                    $mapStmt = $conn->prepare($mapQuery);
                                    $mapStmt->bindParam(':local_id', $localId);
                                    $mapStmt->bindParam(':server_id', $saleId);
                                    $mapStmt->execute();
                                }
                                $results['synced']++;
                            } else {
                                $results['failed']++;
                                $results['errors'][] = 'Failed to sync sale: ' . (isset($result['message']) ? $result['message'] : 'Unknown error');
                            }
                            break;
                            
                        case 'stock':
                            $stock = new Stock();
                            $localId = $record['local_id'] ?? null;
                            
                            if ($localId) {
                                $checkQuery = "SELECT id FROM stock_inventory WHERE local_id = :local_id";
                                $checkStmt = $conn->prepare($checkQuery);
                                $checkStmt->bindParam(':local_id', $localId);
                                $checkStmt->execute();
                                if ($checkStmt->fetch()) {
                                    continue;
                                }
                            }
                            
                            $result = $stock->addStock(
                                $record['product_id'],
                                $branchId,
                                $record['quantity'],
                                $record['unit'] ?? null,
                                $record['batch_number'] ?? null,
                                $record['expiry_date'] ?? null,
                                $record['supplier_id'] ?? null
                            );
                            
                            if ($result) {
                                $stockId = is_array($result) ? ($result['id'] ?? $result) : $result;
                                
                                // Handle cost_price separately if provided
                                if (isset($record['cost_price'])) {
                                    $updateQuery = "UPDATE stock_inventory SET cost_price = :cost_price WHERE id = :id";
                                    $updateStmt = $conn->prepare($updateQuery);
                                    $updateStmt->bindParam(':cost_price', $record['cost_price']);
                                    $updateStmt->bindParam(':id', $stockId);
                                    $updateStmt->execute();
                                }
                                
                                // Store local_id in stock_inventory and mapping
                                if ($localId) {
                                    $updateLocalQuery = "UPDATE stock_inventory SET local_id = :local_id WHERE id = :id";
                                    $updateLocalStmt = $conn->prepare($updateLocalQuery);
                                    $updateLocalStmt->bindParam(':local_id', $localId);
                                    $updateLocalStmt->bindParam(':id', $stockId);
                                    $updateLocalStmt->execute();
                                    
                                    $mapQuery = "INSERT INTO sync_mappings (entity_type, local_id, server_id, created_at) 
                                                VALUES ('stock', :local_id, :server_id, NOW())
                                                ON DUPLICATE KEY UPDATE server_id = :server_id";
                                    $mapStmt = $conn->prepare($mapQuery);
                                    $mapStmt->bindParam(':local_id', $localId);
                                    $mapStmt->bindParam(':server_id', $stockId);
                                    $mapStmt->execute();
                                }
                                
                                $results['synced']++;
                            } else {
                                $results['failed']++;
                                $results['errors'][] = 'Failed to sync stock';
                            }
                            break;
                            
                        case 'customers':
                            $customer = new Customer();
                            $localId = $record['local_id'] ?? null;
                            
                            if ($localId) {
                                $checkQuery = "SELECT id FROM customers WHERE local_id = :local_id";
                                $checkStmt = $conn->prepare($checkQuery);
                                $checkStmt->bindParam(':local_id', $localId);
                                $checkStmt->execute();
                                if ($checkStmt->fetch()) {
                                    continue;
                                }
                            }
                            
                            $record['created_at'] = $record['created_at'] ?? date('Y-m-d H:i:s');
                            $result = $customer->create($record);
                            
                            if ($result) {
                                $customerId = is_array($result) ? ($result['id'] ?? $result) : $result;
                                
                                // Store local_id in customers table and mapping
                                if ($localId) {
                                    $updateLocalQuery = "UPDATE customers SET local_id = :local_id WHERE id = :id";
                                    $updateLocalStmt = $conn->prepare($updateLocalQuery);
                                    $updateLocalStmt->bindParam(':local_id', $localId);
                                    $updateLocalStmt->bindParam(':id', $customerId);
                                    $updateLocalStmt->execute();
                                    
                                    $mapQuery = "INSERT INTO sync_mappings (entity_type, local_id, server_id, created_at) 
                                                VALUES ('customers', :local_id, :server_id, NOW())
                                                ON DUPLICATE KEY UPDATE server_id = :server_id";
                                    $mapStmt = $conn->prepare($mapQuery);
                                    $mapStmt->bindParam(':local_id', $localId);
                                    $mapStmt->bindParam(':server_id', $customerId);
                                    $mapStmt->execute();
                                }
                                $results['synced']++;
                            } else {
                                $results['failed']++;
                                $results['errors'][] = 'Failed to sync customer';
                            }
                            break;
                            
                        default:
                            $results['failed']++;
                            $results['errors'][] = "Unknown entity type: $entity";
                    }
                } catch (Exception $e) {
                    $results['failed']++;
                    $results['errors'][] = $e->getMessage();
                }
            }
            
            $conn->commit();
        } catch (Exception $e) {
            $conn->rollBack();
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Sync failed: ' . $e->getMessage(),
                'results' => $results
            ]);
            exit;
        }
        
        echo json_encode($results);
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>

